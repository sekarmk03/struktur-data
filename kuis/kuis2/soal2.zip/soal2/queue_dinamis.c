#include "header.h"

int main() {
    queue Q1, Q2;
    createEmpty(&Q1);
    createEmpty(&Q2);
    char nama[100], alamat[100], dana[100];
    int n = 0, m = 0, priority = 0;
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%s%d%s%s", nama, &priority, alamat, dana);
        addPriority(nama, alamat, dana, priority, &Q1);
        // printQueue(&Q1, 11, 9);
    }
    scanf("%d", &m);
    printQueue(&Q1, m, 1);
    printQueue(&Q1, countElement(Q1) + 1, 0);
    return 0;
}

/*
7
nani 6 bandung 350000
rohaedi 10 cicalengka 400000
darmaji 1 cilacap 250000
siti 2 garut 500000
yolanda 11 garut 500000
anik 13 garut 600000
yayat 5 tasikmalaya 500000
2

*/