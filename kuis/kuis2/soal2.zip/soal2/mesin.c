#include "header.h"

void createEmpty(queue *Q) {
    (*Q).first = NULL;
    (*Q).last = NULL;
}

int isEmpty(queue Q) {
    int hasil = 0;
    if(Q.first == NULL) {
        hasil = 1;
    }
    return hasil;
}

int countElement(queue Q) {
    int hasil = 0;
    if(Q.first != NULL) {
        elemen *bantu;
        bantu = Q.first;
        while(bantu != NULL) {
            hasil++;
            bantu = bantu->next;
        }
    }
    return hasil;
}

void add(char nama[], char alamat[], char dana[], int priority, queue *Q) {
    elemen *baru;
    baru = (elemen*)malloc(sizeof(elemen));
    strcpy(baru->kontainer.nama, nama);
    strcpy(baru->kontainer.alamat, alamat);
    strcpy(baru->kontainer.dana, dana);
    baru->kontainer.priority = priority;
    baru->next = NULL;
    if((*Q).first == NULL) {
        (*Q).first = baru;
    } else {
        (*Q).last->next = baru;
    }
    (*Q).last = baru;
    baru = NULL;
}

void addPriority(char nama[], char alamat[], char dana[], int priority, queue *Q) {
    elemen *baru;
    baru = (elemen*)malloc(sizeof(elemen));
    strcpy(baru->kontainer.nama, nama);
    strcpy(baru->kontainer.alamat, alamat);
    strcpy(baru->kontainer.dana, dana);
    baru->kontainer.priority = priority;
    baru->next = NULL;
    if((*Q).first == NULL) {
        (*Q).first = baru;
        (*Q).last = baru;
    } else {
        // (*Q).first = baru;
        /*elemen *bantu1 = (*Q).first;
        elemen *bantu2 = (*Q).last;
        if(baru->kontainer.priority <= bantu1->kontainer.priority) {
            baru->next = (*Q).first;
            (*Q).first = baru;
        } else if(baru->kontainer.priority > bantu2->kontainer.priority) {
            baru->next = NULL;
            bantu2->next = baru;
            (*Q).last = baru;
        } else {
            int stop = 0;
            while(bantu1 != NULL && stop == 0) {
                if(bantu1->next->kontainer.priority < baru->kontainer.priority) {
                    // baru->next = bantu1->next;
                    // bantu1->next = baru;
                    // bantu1 = baru->next;
                    bantu1 = bantu1->next;
                } else {
                    baru->next = bantu1->next;
                    bantu1->next = baru;
                    stop = 1;
                }
            }
        }*/
        if(priority == 1) {
            baru->next = (*Q).first;
            (*Q).first = baru;
        } else if(priority > countElement(*Q)) {
            add(nama, alamat, dana, priority, Q);
        } else {
            elemen *bantu = (*Q).first;
            int i = 1;
            while(bantu != NULL) {
                if(i == priority - 1) {
                    baru->next = bantu->next;
                    bantu->next = baru;
                }
                bantu = bantu->next;
                i++;
            }
        }
    }
    baru = NULL;
}

void makePriority(int priority, queue *Q) {
    elemen *left = (*Q).first;
    elemen *right = (*Q).first->next;
    int i = 1;
    while(left->next != NULL) {
        if(left->kontainer.priority > right->kontainer.priority) {
            left->next = right->next;
            right->next = left;
        }
        left = left->next;
    }
}

void del(queue *Q1) {
    if((*Q1).first != NULL) {
        elemen *hapus = (*Q1).first;
        if(countElement(*Q1) == 1) {
            (*Q1).first = NULL;
            (*Q1).last = NULL;
        } else {
            (*Q1).first = (*Q1).first->next;
            hapus->next = NULL;
        }
        free(hapus);
    }
}

void printQueue(queue *Q, int n, int Queue) {
    if(Queue != 0) {
        printf("Bantuan Tersalurkan:\n");
    } else {
        printf("\nAntrian berisi:\n");
    }
    if((*Q).first != NULL) {
        elemen *bantu = (*Q).first;
        int i = 0;
        while(bantu != NULL && i < n) {
            printf("%s %d %s %s\n", bantu->kontainer.nama, bantu->kontainer.priority, bantu->kontainer.alamat, bantu->kontainer.dana);
            bantu = bantu->next;
            del(Q);
            i++;
        }
    } else {
        printf("queue kosong\n");
    }
}